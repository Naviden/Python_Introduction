emp_info = {
            'm1' : {'name' : 'Mario', 'surname' : 'Rossi', 'password' : '12345'},
            'm2' : {'name' : 'Dino', 'surname' : 'Pedreschi', 'password' : '12345'},
            'm3' : {'name' : 'Gianni', 'surname' : 'Tacca', 'password' : '12345'},
            'm4' : {'name' : 'Oliver', 'surname' : 'Stone', 'password' : '12345'},
           }